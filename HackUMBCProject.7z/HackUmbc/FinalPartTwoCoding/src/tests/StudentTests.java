package tests;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import programs.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
   
	@Test
    public void  getLengthLargestRowTest1() {
        
		int data[][] = {{30} , {10, 6, 9, 2, 89}, {77, 20, 2}};
		
		System.out.println(Utilities.getLengthLargestRow(data));
    }
	
	@Test
	public void getLengthLargestRowTest2() {
        
		int data[][] = {{} , {}, {}};
		
		System.out.println(Utilities.getLengthLargestRow(data));
    }
	
	@Test
	public void getLengthLargestRowTest3() {
        
		int data[][] = {{} , {}, {1}};
		
		System.out.println(Utilities.getLengthLargestRow(data));
    }
	
	@Test
	public void duplicateAndFillTest1() {
        
		int data[] = {30, 4, 6, 8};
		int expectedResult[] = {30, 4, 6, 8, 9, 9, 9, 9, 9};
		
		assertArrayEquals(Utilities.duplicateAndFill(data, 9, 9), expectedResult);
    }
	
	@Test
	public void duplicateAndFillTest2() {
        
		int data[] = {1, 2};
		int expectedResult[] = {1, 2, 3};
		
		assertArrayEquals(Utilities.duplicateAndFill(data, 3, 3), expectedResult);
    }
	
	@Test
	public void getNonRaggedArrayTest1() {
        
		int data[][] = { {30} , {10,6,9,2,89} , {77,20,2}};
		int expectedResult[][] = {{30,4,4,4,4} , {10,6,9,2,89} , {77,20,2,4,4}};
		
		assertArrayEquals(Utilities.getNonRaggedArray(data, 4), expectedResult);
    }
	
	@Test
	public void getNonRaggedArrayTest2() {
        
		int data[][] = {null, {10,6,9,2,89}, {77,20,2}};
		int expectedResult[][] = {{4,4,4,4,4} , {10,6,9,2,89} , {77,20,2,4,4}};
		
		assertArrayEquals(Utilities.getNonRaggedArray(data, 4), expectedResult);
    }
}