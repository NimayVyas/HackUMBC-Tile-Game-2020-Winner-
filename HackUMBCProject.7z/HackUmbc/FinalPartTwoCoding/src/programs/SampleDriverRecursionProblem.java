package programs;

import java.util.Arrays;

/* 
 * You can use this code to write your own tests  
 */
public class SampleDriverRecursionProblem {

	public static void main(String[] args) {
		String answer = "";

		answer += "**** RecursionProblem.replaceVowelsWith ****\n";
		String str = "thEskyisblue", replacement = "*-";
		answer += "Replacement: " + replacement + "\n";
		answer += "Original: " + str + "\n";
		answer += "  Result: " + RecursionProblem.replaceVowelsWith(str, replacement);
		answer += "\n\n";

		answer += "**** RecursionProblem.setToPositive ****\n";
		int[] values = { -89, 4, 700, -6, -9 };
		answer += "Original Array: " + Arrays.toString(values) + "\n";
		int changed = RecursionProblem.setToPositive(values);
		answer += "After Processing: " + Arrays.toString(values) + "\n" ;
		answer += "Number of values changed: " + changed;

		System.out.println(answer);
	}

}
