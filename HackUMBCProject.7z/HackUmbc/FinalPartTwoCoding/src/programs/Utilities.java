package programs;

public class Utilities {
	public static int getLengthLargestRow(int[][] data) {

		int maxLength = 0;

		if (data == null) {
			throw new IllegalArgumentException("Invalid Parameter");
		}

		for (int i = 0; i < data.length; i++) {

			if (data[i] == null || data[i].length == 0 && maxLength >= 0) {
				maxLength = 0;
			} else if (data[i].length > maxLength) {
				maxLength = data[i].length;
			}
		}

		return maxLength;

	}

	public static int[] duplicateAndFill(int[] data, int newLength, int filler) {

		int[] duplicatedArray;
		int idx = 0;

		if (data == null || data.length > newLength) {
			throw new IllegalArgumentException("Invalid Parameter");
		} else {

			duplicatedArray = new int[newLength];

			for (int i = 0; i < data.length; i++) {
				duplicatedArray[i] = data[i];
				idx++;
			}

			for (int i = duplicatedArray.length - data.length; i > 0; i--) {
				duplicatedArray[idx] = filler;
				idx++;
			}

			return duplicatedArray;

		}

	}

	public static int[][] getNonRaggedArray(int[][] data, int filler) {
	
		if (data == null || filler < 0) {
			throw new IllegalArgumentException();
		}
		
		int[][] resultArray = new int[data.length][getLengthLargestRow(data)];
		
		for (int i = 0; i < resultArray.length; i++) {
			if (data[i] == null) {
				resultArray[i] = duplicateAndFill(new int[0], getLengthLargestRow(data), filler);
			} else if (data[i].length == getLengthLargestRow(data)) {
				for (int j = 0; j < resultArray[i].length; j++) {
					resultArray[i][j] = data[i][j];
				} 
			} else {
				resultArray[i] = duplicateAndFill(data[i], getLengthLargestRow(data), filler);
			}
		}
		
		return resultArray;
	}
}
