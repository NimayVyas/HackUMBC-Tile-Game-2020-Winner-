package programs;

import java.util.ArrayList;

public class Train implements CargoVehicle, Comparable<Train> {
	private String name;
	private int numberOfTrainCars;
	private TrainCar[] allTrainCars;

	public Train(String name, int maxTrainCars) {
		this.name = name;
		numberOfTrainCars = 0;
		allTrainCars = new TrainCar[maxTrainCars];
	}

	public boolean addTrainCar() {
		if (numberOfTrainCars < allTrainCars.length) {
			allTrainCars[numberOfTrainCars] = new TrainCar();
			numberOfTrainCars++;
			return true;
		} else {
			return false;
		}
	}

	public boolean addItemToCar(String itemsName, int tons, int trainCarIndex) {
		if (itemsName == null || trainCarIndex < 0 || tons < 0 || trainCarIndex > allTrainCars.length) {
			throw new IllegalArgumentException("Invalid Parameter");
		} else {
			allTrainCars[trainCarIndex].addItem(itemsName, tons);
			return true;
		} 
	}

	/* Provided: Please do not modify */
	public String toString() {
		String answer = "";

		answer += "Name: " + name + "\n";
		answer += "NumberOfTrainCars: " + numberOfTrainCars + "\n";
		answer += "TrainCars:" + "\n";
		for (int i = 0; i < numberOfTrainCars; i++) {
			answer += allTrainCars[i] + "\n";
		}

		return answer;
	}

	/* Provided: Please do not modify */
	public String getName() {
		return name;
	}

	/* Provided: Please do not modify */
	public int getNumberOfTrainCars() {
		return numberOfTrainCars;
	}

	public int getTons() {
		int totalTons = 0;
		for (int i = 0; i < allTrainCars.length; i++) {
			totalTons = totalTons + allTrainCars[i].getTons();
		}
		return totalTons;
	}

	public StringBuffer getItems() {
		StringBuffer allItemStringBuffer = new StringBuffer();
		for (int i = 0; i < allTrainCars.length; i++) {
			allItemStringBuffer.append(allTrainCars[i].getItems());
		}
		return allItemStringBuffer;
	}

	public int compareTo(Train train) {
		return 1;
	
	}

	public Train getTrainWithCars(String name, int[] trainCarIndices) {

		Train copiedTrain = new Train(name, trainCarIndices.length);
		
		for (int i = 0; i < trainCarIndices.length; i++) {
			if (trainCarIndices[i] < this.allTrainCars.length ) {
				copiedTrain.allTrainCars[i] = new TrainCar(this.allTrainCars[i]);
			}
		}
		
		return copiedTrain;
		 
	}

	public static int getNumberOfTrainCars(ArrayList<CargoVehicle> vehicles) {
		
		int totalTrainCars = 0;
	
		for (int i = 0; i < vehicles.size(); i++) {
			if (vehicles.get(i) instanceof Train) {
				
			}
		}
		
		return totalTrainCars;
	}
}