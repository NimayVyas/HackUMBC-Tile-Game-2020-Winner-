package programs;

/* 
 * You can use this code to write your own tests  
 */
public class SampleDriverTrainCar {
	public static void main(String[] args) {
		String answer = "";

		answer += "**** TrainCar ****\n";
		TrainCar trainCar = new TrainCar();
		answer += "Initial TrainCar->   " + trainCar + "\n";
		trainCar.addItem("Tables", 4).addItem("Chairs", 9);
		answer += "After adding items-> " + trainCar + "\n";
		answer += "Get tons-> " + trainCar.getTons() + "\n";
		answer += "Get items-> " + trainCar.getItems() + "\n";
		TrainCar copy = new TrainCar(trainCar);
		answer += "Copy: " + copy;

		System.out.println(answer);
	}
}
