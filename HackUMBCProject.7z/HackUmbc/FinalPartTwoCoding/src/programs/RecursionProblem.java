package programs;

public class RecursionProblem {
	
	public static String replaceVowelsWith(String str, String replacement) {
		
		if (str == null || replacement == null) {
			throw new IllegalArgumentException("Invalid Parameters");
		}
		
		
		if (str.length() == 0) {
			return "";
		} else if (str.charAt(0) == 'a' ||  str.charAt(0) == 'e' || str.charAt(0) == 'i'
				|| str.charAt(0) == 'o' || str.charAt(0) == 'u' || str.charAt(0) == 'A' 
				|| str.charAt(0) == 'E' || str.charAt(0) == 'I'
				|| str.charAt(0) == 'O' || str.charAt(0) == 'U') {
			return replacement += replaceVowelsWith(str.substring(1), replacement);
		} else {
			return Character.toLowerCase(str.charAt(0)) + replaceVowelsWith(str.substring(1), replacement);
		}
	}

	public static int setToPositive(int[] array) {
		
		if (array == null) {
			throw new IllegalArgumentException("Invalid Parameters");
		}
		
		return setToPositiveAuxillary(array, 0);
	}
	
	private static int setToPositiveAuxillary(int[] array, int idx) {
		
		if (idx > array.length - 1) {
			return 0;
		} else if (array[idx] < 0) {
			array[idx] = array[idx] * -1;
			return 1 + setToPositiveAuxillary(array, idx + 1);
		} else {
			return setToPositiveAuxillary(array, idx + 1);
		}
		
		
	}
}
