package programs;

import java.util.ArrayList;

public class TrainCar {
	private int tons;
	private ArrayList<String> trainCarItems;

	public TrainCar() {
		this.tons = 0;
		trainCarItems = new ArrayList<String>();
	}

	public TrainCar(TrainCar trainCar) {
		tons = trainCar.tons;
		trainCarItems = trainCar.trainCarItems;
	}

	public TrainCar addItem(String itemsName, int tons) {
		if (itemsName == null || tons <= 0) {
			throw new IllegalArgumentException("Invalid Parameters");
		}
		this.trainCarItems.add(itemsName + tons);
		this.tons += tons;
		return this;
	}

	public String getItems() {
		return trainCarItems.toString();
	}

	public int getTons() {
		return tons;
	}

	/* Provided: Please do not modify */
	public String toString() {
		return "Tons: " + tons + ", Items: " + trainCarItems;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (this == null || getClass() != obj.getClass()) {
			return false;
		}

		TrainCar trainCar = (TrainCar) obj;
		return (this.tons == trainCar.tons || this.trainCarItems.equals(trainCar.trainCarItems));
	}
}