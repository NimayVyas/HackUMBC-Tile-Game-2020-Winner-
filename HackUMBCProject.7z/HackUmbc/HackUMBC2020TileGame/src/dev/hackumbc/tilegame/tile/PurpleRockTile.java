package dev.hackumbc.tilegame.tile;

import dev.hackumbc.tilegame.gfx.Assets;

public class PurpleRockTile extends Tile {

	public PurpleRockTile(int id) {
		super(Assets.purplerock, id);
	}
	
}
