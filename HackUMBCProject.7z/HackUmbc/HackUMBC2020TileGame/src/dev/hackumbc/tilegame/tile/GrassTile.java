package dev.hackumbc.tilegame.tile;

import dev.hackumbc.tilegame.gfx.Assets;

public class GrassTile extends Tile {
	
	public GrassTile(int id) {
		super(Assets.grasstile, id);
	}
	
}
