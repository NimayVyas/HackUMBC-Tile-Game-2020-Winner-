package dev.hackumbc.tilegame.gfx;

import java.awt.image.BufferedImage;

public class Assets {

	private static final int width = 32, height = 32;

	public static BufferedImage purplerock, rocktile, grasstile, tree, darkness;
	public static BufferedImage[] player_down, player_up, player_left, player_right;

	public static void intit() {
		SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/tiles.png"));
		SpriteSheet playerSheet =  new SpriteSheet(ImageLoader.loadImage("/textures/heroanimations.png"));
		
		player_down = new BufferedImage[3];
		player_up = new BufferedImage[3];
		player_left = new BufferedImage[2];
		player_right = new BufferedImage[2];
		
		player_down[0] = playerSheet.crop(0, 132, (width + 6), (height + 10));
		player_down[1] = playerSheet.crop(130, 0, (width + 6), (height + 10));
		player_down[2] = playerSheet.crop(0, 132, (width + 6), (height + 10));
		player_up[0] = playerSheet.crop(0, 132, (width + 6), (height + 10));
		player_up[1] = playerSheet.crop(130, 0, (width + 6), (height + 10));
		player_up[2] = playerSheet.crop(0, 132, (width + 6), (height + 10));
		player_left[0] = playerSheet.crop(86, 132, (width + 6), (height + 10));
		player_left[1] = playerSheet.crop(132, 132, (width + 6), (height + 10));
		player_right[0] = playerSheet.crop(30, 90, (width + 8), (height + 10));
		player_right[1] = playerSheet.crop(75, 90, (width + 8), (height + 10));
		
		purplerock = sheet.crop(128, 0, width, height);
		rocktile = sheet.crop(128, 512, width, height);
		grasstile = sheet.crop(128, 640, width, height);
		darkness = sheet.crop(122, 672, (width), (height));
		

	}
}