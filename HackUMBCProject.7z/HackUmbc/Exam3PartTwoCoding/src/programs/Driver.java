package programs;

public class Driver {

	public static void main(String[] args) {
		String answer = "";

		answer += "Utilities Methods\n";
		int[] ages = { 10, 14, 10, 6 };
		answer += "getString: " + Utilities.getString(ages, "[[", "]]");
		int[] added = Utilities.addNeighborValue(ages);
		answer += "\nBefore adding neighbor: " + Utilities.getString(ages, "[", "]");
		answer += "\nResult of adding neighbor: " + Utilities.getString(added, "[", "]");
		
		answer += "\n\nStory Class\n";
		String title = "Terps Win", text = "Terps win game in overtime; best game!.\n";
		int sources = 4;
		Story story1 = new Story(title, text, sources);
		answer += "Original:\n" + story1;
		Story story2 = new Story(story1);
		answer += "\n\nCopy:\n" + story2;

		story1.addToStory("Terps celebrate at the Union\n").addToStory("Party still going on.\n");
		answer += "\n\nAfter addToStory:\n" + story1;

		answer += "\ngetTitle: " + story1.getTitle() + "\n";
	
		/* Newspaper */
		int maxStories = 10;
		Newspaper newspaper1 = new Newspaper("UMCP News", maxStories);
		newspaper1.addStory("Compiler Works", "Java compiler works after two weeks.", 400);
		newspaper1.addStory("Parking Ready", "After two weeks everyone gets a parking space.", 23);
		newspaper1.addStory("New Compiler", "A new compiler has been release; better speed.", 800);
		newspaper1.addStory("The Old Parking", "The old parking is still available.", 501);
		newspaper1.addStory("Metro Parking", "Metro parking has been expanded.", 701);

		answer += newspaper1 + "\n";
		Story[] stories = newspaper1.getStories();
		answer += "All Stories #1: " + "\n";
		for (Story story : stories) {
			answer += story + "\n";
		}

		answer += "\nAll Stories #2:\n";
		Story[] result = new Story[newspaper1.getMaxStories()];
		int found = newspaper1.getStories(null, result);
		for (int i = 0; i < found; i++) {
			answer += result[i] + "\n";
		}

		String target = "Compiler";
		answer += "\nSelected Stories with " + target + " in title\n";
		result = new Story[newspaper1.getMaxStories()];
		found = newspaper1.getStories(target, result);
		for (int i = 0; i < found; i++) {
			answer += result[i] + "\n";
		}

		answer += "\n\nNewspaper with first n Stories \n";
		int n = 3;
		Newspaper newspaperNStories = newspaper1.firstNStories("Top Stories Paper", n);
		answer += newspaperNStories + "\n";

		answer += "\nRemoving Stories with " + target + " in title\n";
		int removed = newspaper1.removeStories(target);
		answer += "Removed: " + removed + "\n";
		answer += newspaper1 + "\n";

		System.out.println(answer);
	}
}
