package programs;

public class Utilities {
	
	public static String getString(int[] data, String startMarker, String endMarker) {

		if (data == null || startMarker.length() != endMarker.length()) {
			throw new IllegalArgumentException("Error Invalid Parameter");
		}
		
		String resultString = "";
		
		resultString += startMarker;
		
			for (int i = 0; i < data.length; i++) {
				
				resultString += i;
				resultString += " ";
				
			}
		
		resultString += endMarker;
		
		return resultString;
			
		
	}

	public static int[] addNeighborValue(int[] data) {
		
		if (data == null || data.length == 0) {
			throw new IllegalArgumentException("Error Invalid Parameter");
		}
		
		int [] resultArray = new int[data.length];
		
		if (data.length > 1) {
			for (int i = 0; i < resultArray.length - 1; i++) {
				resultArray[i] = data[i] + data[i + 1];
			}
		}
		
		resultArray[resultArray.length - 1] = data[data.length - 1];
		
		return resultArray;
		
	}
}
