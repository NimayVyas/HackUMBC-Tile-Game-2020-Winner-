package programs;

public class Story {
	private String title;
	private StringBuffer storyText;
	private int sources;

	public Story(String title, String text, int sources) {
		
		if (title == null || sources < 0 || text == null) {
			throw new IllegalArgumentException("Invalid Parameter");
		}
		
		this.title = title;
		this.sources = sources;
		storyText = new StringBuffer();
		storyText.append(text);
		
	}

	public Story(Story story) {
		this.title = story.title;
		this.sources = story.sources;
		this.storyText = new StringBuffer(story.storyText);
	}

	public Story addToStory(String text) {
		if (text != null) {
			this.storyText.append(text);
		}
		return this;
	}

	/* Provided: Please do not modify */
	public String toString() {
		String answer = "Title: \"" + title + "\"\n";

		answer += "Sources: " + sources + "\n";
		answer += "Story Text: " + storyText;

		return answer;
	}

	public String getTitle() {
		return title;
	}
}