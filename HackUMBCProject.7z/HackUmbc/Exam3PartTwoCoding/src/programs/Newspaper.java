package programs;

public class Newspaper {
	private String name;
	private Story[] allStories;
	private int numberOfStories;

	public Newspaper(String name, int maxStories) {
		 this.name = name;
		 allStories = new Story[maxStories];
		 numberOfStories = 0;
	}

	public boolean addStory(String title, String text, int sources) {
		
		if (numberOfStories < getMaxStories()) {
			allStories[numberOfStories] = new Story(title, text, sources);
			numberOfStories++;
			return true;
		 } else {
			return false;
		}
	}

	/* Provided: Please do not modify */
	public String toString() {
		String answer = "NewsPaper's Name: " + name + "\n";

		answer += "Number of Stories: " + numberOfStories + "\n\n";
		for (int i = 0; i < numberOfStories; i++) {
			answer += allStories[i] + "\n\n";
		}

		return answer;
	}

	public Story[] getStories() {
		 Story[] getStoriesArray = new Story[numberOfStories];
		 for (int i = 0; i < getStoriesArray.length; i++) {
			getStoriesArray[i] = allStories[i];
		}
		return getStoriesArray;
	}

	/* Provided: Please do not modify */
	public int getMaxStories() {
		return allStories.length;
	}

	public int getStories(String withInTitle, Story[] result) {
	
		int numberOfStoriesAdded = 0;
		
		if (withInTitle == null) {
			
			for (int i = 0; i < getMaxStories(); i++) {
				allStories[i] = result[i];
				numberOfStoriesAdded++;
			}
			
		} else {
			
			int resultIndex = 0;
			
			for (int i = 0; i < getMaxStories(); i++) {
			
				if (allStories[i].getTitle().contains(withInTitle)) {
					allStories[i] = result[resultIndex];
					numberOfStoriesAdded++;
				}
			}
			
		}
	
		return numberOfStoriesAdded;
	}

	public Newspaper firstNStories(String title, int n) {
		
		if (title == null || n < 0) {
			throw new IllegalArgumentException("Invalid Parameter");
		}
		
		if (n == 0) {
			Newspaper newspaper = new Newspaper(title, 0);
			return newspaper;
		} else if (n > numberOfStories) {
			Newspaper newspaper = new Newspaper(title, getMaxStories());
			numberOfStories = getMaxStories();
			return newspaper;
		} else {
			Newspaper newspaper = new Newspaper(title, n);
			numberOfStories = n;
			return newspaper;
		}
		
	}

	public int removeStories(String withInTitle) {
		
		int numberOfElementsRemoved = 0;
		
		if (withInTitle == null) {
			throw new IllegalArgumentException("Invalid Parameter");
		} else {
			for (int i = 0; i < allStories.length; i++) {
				if (allStories[i].getTitle().contains(withInTitle)) {
					numberOfElementsRemoved++;
				}
			}
		}
		
		Story[] removedElementsArrayStories = new Story[numberOfElementsRemoved];
		int counter = 0;
		
		for (int i = 0; i < removedElementsArrayStories.length - numberOfElementsRemoved; i++) {
			if (allStories[i].getTitle().contains(withInTitle)) {
				
			} else {
				removedElementsArrayStories[counter] = allStories[i];
				counter++;
			}
		}
		
		return numberOfElementsRemoved;
	}
}
