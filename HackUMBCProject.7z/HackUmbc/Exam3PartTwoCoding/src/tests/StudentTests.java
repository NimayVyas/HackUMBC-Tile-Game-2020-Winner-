package tests;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import programs.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class StudentTests {
  
	@Test
    public void getStringTest1() {
		int[] data = {1, 2, 5, 6};
		String expectString = "(0 1 2 3 )";
		assertTrue(expectString.equals(Utilities.getString(data, "(", ")")));
    }
	
	@Test(expected = IllegalArgumentException.class)
    public void getStringTest2() {
		int[] data = null;
		String expectString = "(0 1 2 3 )";
		assertTrue(expectString.equals(Utilities.getString(data, "(", ")")));
    }
	
	@Test(expected = IllegalArgumentException.class)
    public void getStringTest3() {
		int[] data = null;
		String expectString = "(0 1 2 3 )";
		assertTrue(expectString.equals(Utilities.getString(data, "Laal", ")")));
    }
	
	@Test
    public void addNeigborValueTest1() {
		int[] data = {1, 2, 5, 6};
		int[] resultArray = Utilities.addNeighborValue(data);
		int[] expectedResults = {3, 7, 11, 6};
		assertArrayEquals(resultArray, expectedResults);
    }
	
	@Test(expected = IllegalArgumentException.class)
    public void addNeigborValueTest2() {
		int[] data = {};
		String expectString = "(0 1 2 3 )";
		assertTrue(expectString.equals(Utilities.getString(data, "Laal", ")")));
    }
	
	@Test
    public void addNeigborValueTest3() {
		int[] data = {7};
		int[] resultArray = Utilities.addNeighborValue(data);
		int[] expectedResults = {7};
		assertArrayEquals(resultArray, expectedResults);
    }
	
	@Test
    public void storyContructorTest1() {
		Story story = new Story("Sleeping Beauty", "A Love Letter Came Through"
				+ " The Mail ", 3);
		System.out.println(story.toString());
    }
	
	@Test
    public void storyCopyConstructorTest1() {
		Story story = new Story("Sleeping Beauty", "A Love Letter Came Through"
				+ " The Mail ", 3);
		Story story1 = new Story("Sleeping Beauty", "A Love Letter Came Through"
				+ " The Mail ", 3);
		story = new Story(story1);
		System.out.println(story.toString());
    }
	
	@Test
    public void addTextTest1() {
		Story story = new Story("Sleeping Beauty", "A Love Letter Came Through"
				+ " The Mail ", 3);
		story.addToStory("Play The Marriage All Night On Ur TV");
		System.out.println(story.toString());
    }
	
	@Test
    public void addStoryTest1() {
		Newspaper newspaper = new Newspaper("Newspaper", 4);
		newspaper.addStory("Hi", "Wassup", 3);
		System.out.println(newspaper);
    }
	
	@Test
    public void getStoryTest1() {
		Newspaper newspaper = new Newspaper("Newspaper", 4);
		newspaper.addStory("Hi", "static", 3);
		newspaper.addStory("hola", "Wassup", 3);
		newspaper.addStory("Him", "static", 3);
		newspaper.addStory("hola", "Wassup", 3);
		Story[] result = new Story[4];
		System.out.println(newspaper.getStories(null, result));
    }


	
	
	
}